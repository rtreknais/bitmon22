﻿using BitmonGeneration1.Source.Battles;
using BitmonGeneration1.Source.Moves;
using BitmonGeneration1.Source.BitmonData;
using System;
using System.Collections.Generic;

namespace BitmonStadiumConsoleApp
{
    public static class Display
    {
        public static void Bitmon(BattleBitmon myBitmon, BattleBitmon opponentBitmon, string myName, string opponentName)
        {
            //opponent
            Console.WriteLine();
            Console.WriteLine(opponentName);
            Console.WriteLine(opponentBitmon.Name);
            Console.WriteLine("STAM:"+ opponentBitmon.Level + " " + StatusToString(opponentBitmon.Status));
            Console.WriteLine("HP: " + opponentBitmon.HP + "/" + opponentBitmon.MaxHP);
            Console.WriteLine();

            //player
            Console.WriteLine(RightJustify(myBitmon.Name, 32));
            Console.WriteLine(RightJustify("STAM:" + StatusToString(myBitmon.Status) + " " + myBitmon.Level, 32));
            Console.WriteLine(RightJustify("HP: " + myBitmon.HP + "/" + myBitmon.MaxHP, 32));
            Console.WriteLine(RightJustify(myName, 32));
            Console.WriteLine();
        }
        private static string StatusToString(Status status)
        {
            switch (status)
            {
                case Status.BadlyPoisoned:
                    return "PSN";
                case Status.Burn:
                    return "BRN";
                case Status.Fainted:
                    return "FNT";
                case Status.Freeze:
                    return "FRZ";
                case Status.Paralysis:
                    return "PAR";
                case Status.Poison:
                    return "PSN";
                case Status.Sleep:
                    return "SLP";
                default:
                    return "";
            }
        }
        public static string RightJustify(string original, int charsPerLine)
        {
            for (int i = original.Length; i < charsPerLine + 1; i++)
            {
                original = " " + original;
            }
            return original;
        }
        public static string LeftJustify(string original, int charsPerLine)
        {
            for (int i = original.Length; i < charsPerLine + 1; i++)
            {
                original = original + " ";
            }
            return original;
        }

        public static void MainPrompt()
        {
            Console.WriteLine();
            Console.Write("(1) FIGHT");
            Console.WriteLine("  (2) REST");
            Console.Write("(3) CHANGE");
            Console.WriteLine();
            Console.Write("Type number and press enter: ");
        }

        public static void MovePrompt(Side actorSide)
        {
            Console.WriteLine();

            Move move1 = actorSide.CurrentBattleBitmon.Move1;
            Move move2 = actorSide.CurrentBattleBitmon.Move2;
            Move move3 = actorSide.CurrentBattleBitmon.Move3;
            Move move4 = actorSide.CurrentBattleBitmon.Move4;

            Console.WriteLine("(1) " + move1.Name + " " );
            if (move2 != null)
            {
                Console.WriteLine("(2) " + move2.Name + " " );
            }
            if (move3 != null)
            {
                Console.WriteLine("(3) " + move3.Name + " " );
            }
            
            Console.WriteLine("(0) - - - back - - -");
            Console.Write("Type number and press enter: ");
        }

        public static void BitmonPrompt(Side actorSide)
        {
            Console.WriteLine();

            List<Bitmon> party = actorSide.Party;

            Console.WriteLine("Select Bitmon:");
            Console.WriteLine("------------------");
            for (int i = 0; i < party.Count; i++)
                Console.WriteLine((i + 1) + " " + party[i].Nickname + " " + StatusToString(party[i].Status));
            Console.WriteLine();
            Console.Write("Type number and press enter");
        }
    }
}
