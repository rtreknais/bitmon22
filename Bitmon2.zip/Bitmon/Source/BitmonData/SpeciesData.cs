﻿namespace BitmonGeneration1.Source.BitmonData
{
    public static class SpeciesData
    {

        public static readonly string[] Names = new string[]
        {
            "Null",
            "Charmon", // 1
            "Bitmeleon",
            "Pikamon",
            "Qwertymon",
            "Squimon",
            "Worbimon",
            "Icemon",
            "Dragonice",
            "Tirimon",
            "Naidormon", //10
            
        };





        public static readonly Type[][] Types = new Type[][]
        {
            //0 - No Pokemon
            new Type[] { Type.Null, Type.Null },
            //1 - Bulbasaur                      
            new Type[] { Type.Grass, Type.Poison },
            //2 - Ivysaur
            new Type[] { Type.Grass, Type.Poison },
            //3 - Venusaur
            new Type[] { Type.Grass, Type.Poison },
            //4 - Charmander
            new Type[] { Type.Fire, Type.Null },
            //5 - Charmeleon
            new Type[] { Type.Fire, Type.Null },
            //6 - Charizard
            new Type[] { Type.Fire, Type.Flying },
            //7 - Squirtle
            new Type[] { Type.Water, Type.Null },
            //8 - Wartortle
            new Type[] { Type.Water, Type.Null },
            //9 - Blastoise
            new Type[] { Type.Water, Type.Null },
            //10 - Caterpie
            new Type[] { Type.Bug, Type.Null },
            
        };
        


        
        public static readonly ExperienceGroup[] ExpGroup = new ExperienceGroup[]
        {
            //0 - No Pokemon
            ExperienceGroup.Fast,
            //1 - Bulbasaur
            ExperienceGroup.MediumSlow,
            //2 - Ivysaur
            ExperienceGroup.MediumSlow,
            //3 - Venusaur
            ExperienceGroup.MediumSlow,
            //4 - Charmander
            ExperienceGroup.MediumSlow,
            //5 - Charmeleon
            ExperienceGroup.MediumSlow,
            //6 - Charizard
            ExperienceGroup.MediumSlow,
            //7 - Squirtle
            ExperienceGroup.MediumSlow,
            //8 - Wartortle
            ExperienceGroup.MediumSlow,
            //9 - Blastoise
            ExperienceGroup.MediumSlow,
            //10 - Caterpie
            ExperienceGroup.MediumFast,
           
        };


        

        public static readonly Stats[] BaseStats = new Stats[]
        {   // 0 - No Pokemon
            new Stats(0f, 0f, 0f, 0f, 0f),
            // 1 - Bulbasaur
            new Stats(45f, 49f, 49f, 65f, 45f),
            // 2 - Ivysaur
            new Stats(60f, 62f, 63f, 80f, 60f),
            // 3 - Venusaur
            new Stats(80f, 82f, 83f, 100f, 80f),
            // 4 - Charmander
            new Stats(39f, 52f, 43f, 50f, 65f),
            // 5 - Charmeleon
            new Stats(58f, 64f, 58f, 65f, 80f),
            // 6 - Charizard
            new Stats(78f, 84f, 78f, 85f, 100f),
            // 7 - Squirtle
            new Stats(44f, 48f, 65f, 50f, 43f),
            // 8 - Wartortle
            new Stats(59f, 63f, 80f, 65f, 58f),
            // 9 - Blastoise
            new Stats(79f, 83f, 100f, 85f, 78f),
            // 10 - Caterpie
            new Stats(45f, 30f, 35f, 20f, 45f),
            
        };


        public static readonly float[] CatchRate = new float[]
        {
            0f,   //0 - NoPokemon
            45f,  //1 - Bulbasaur
            45f,  //2 - Ivysaur
            45f,  //3 - Venusaur
            45f,  //4 - Charmander
            45f,  //5 - Charmeleon
            45f,  //6 - Charizard
            45f,  //7 - Squirtle
            45f,  //8 - Wartortle
            45f,  //9 - Blastoise
            255f, //10 - Caterpie
           
        };


        
        public static readonly float[] ExpYield = new float[]
        {
            0f,   //0 - NoPokemon
            64f,  //1 - Bulbasaur
            141f, //2 - Ivysaur
            208f, //3 - Venusaur
            65f,  //4 - Charmander
            142f, //5 - Charmeleon
            209f, //6 - Charizard
            66f,  //7 - Squirtle
            143f, //8 - Wartortle
            210f, //9 - Blastoise
            53f,  //10 - Caterpie
            
        };
    }
}
