﻿using System;

namespace BitmonGeneration1.Source.BitmonData
{
    public static class StatCalculator
    {
        public static Stats CreateStatsFor(Bitmon bitmon)
        {
            return new Stats(
                HPStat(
                    bitmon.BaseHP,
                    bitmon.HPDV,
                    StatPoint(bitmon.HPExp),
                    bitmon.Level),
                NonHPStat(
                    bitmon.BaseAttack,
                    bitmon.AttackDV,
                    StatPoint(bitmon.AttackExp),
                    bitmon.Level),
                NonHPStat(
                    bitmon.BaseDefense,
                    bitmon.DefenseDV,
                    StatPoint(bitmon.DefenseExp),
                    bitmon.Level),
                NonHPStat(
                    bitmon.BaseSpecial,
                    bitmon.SpecialDV,
                    StatPoint(bitmon.SpecialExp),
                    bitmon.Level),
                NonHPStat(
                    bitmon.BaseSpeed,
                    bitmon.SpeedDV,
                    StatPoint(bitmon.SpeedExp),
                    bitmon.Level));
        }

        public static float NonHPStat(
            float baseStat,
            float DV,
            float statPoint,
            float level)
        {
            return (float)Math.Floor(((((baseStat + DV) * 2) + statPoint) * level / 100) + 5);
        }


        public static float HPStat(
            float baseStat,
            float DV,
            float statPoint,
            float level)
        {
            return (float)Math.Floor(((((baseStat + DV) * 2) + statPoint) * level / 100) + level + 10);
        }


        public static float StatPoint(float statExp)
        {
            return (float)Math.Floor(Math.Min(255f, Math.Floor(Math.Sqrt(Math.Max(0, statExp - 1f)) + 1f)) / 4f);
        }
    }
}
