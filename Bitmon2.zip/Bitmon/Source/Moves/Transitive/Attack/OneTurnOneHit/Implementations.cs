﻿using BitmonGeneration1.Source.Battles;
using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitmonGeneration1.Source.Moves.Transitive.Attack.OneTurnOneHit
{

    // 1
    public sealed class Ember : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public Ember() : base(1, "Ember", Type.Fire,  100f, 40f, 0, false, Category.PHYSICAL)
        {
        }
    }

    //2
    public sealed class FireFang : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
            }
            SetLastMoveAndMirrorMove(user, defender);
            

        }

        public FireFang() : base(2, "Fire Fang", Type.Normal, 100f, 50, 0, true, Category.PHYSICAL) { }
    }

    //3
    public sealed class FireSping : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public FireSping() : base(5, "Fire Spin", Type.Normal,  85f, 80f, 0, false, Category.PHYSICAL) { }
    }

    //4
    public sealed class FlameThrower : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public FlameThrower() : base(6, "Flame Thrower", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //5
    public sealed class IceShard : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public IceShard() : base(5, "Ice Shard", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //6
    public sealed class FrostBreath : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public FrostBreath() : base(6, "Frost Breath", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //7
    public sealed class PowderSnow : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public PowderSnow() : base(7, "Powder Snow", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //8
    public sealed class Hypothermia : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public Hypothermia() : base(8, "Hypothermia", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //9
    public sealed class WaterGun : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public WaterGun() : base(9, "Water Gun", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //10
    public sealed class PoisonGun : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public PoisonGun() : base(10, "Poison Gun", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //11
    public sealed class Bubble: OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public Bubble() : base(11, "Bubble", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //12
    public sealed class WaterFall : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public WaterFall() : base(12, "Waterfall", Type.Normal, 100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //13
    public sealed class ThunderShock : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public ThunderShock() : base(13, "Thunder Shock", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //14
    public sealed class Spark : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public Spark() : base(14, "Spark", Type.Normal, 100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //15
    public sealed class ChargeBeam : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public ChargeBeam() : base(15, "Charge Beam", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }

    //16
    public sealed class VoltSwitch : OneTurnOneHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectivenessUpdateCritFlagAndDoDamage(user, defender);
                OnPayDayTriggered();
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public VoltSwitch() : base(16, "Volt Switch", Type.Normal,  100f, 40f, 0, false, Category.PHYSICAL) { }
    }
}
