﻿using BitmonGeneration1.Source.Battles;

namespace BitmonGeneration1.Source.Moves.Reflexive
{
    public abstract class ReflexiveStatusMove : Move
    {
        public override sealed void ExecuteAndUpdate(
            BattleBitmon user, BattleBitmon defender)
        {
            Execute(user);
        }

        protected abstract void Execute(BattleBitmon user);
        
        protected void SetLastMoveAndSubtractPP(BattleBitmon user)
        {
            user.LastMoveUsed = this;
            
        }
        
        protected ReflexiveStatusMove(int index, string name, Type type)
            : base(index, name, type, 0, Category.STATUS) { }
    }
}
