﻿namespace BitmonGeneration1.Source.Battles
{
    public enum Category
    {
        PHYSICAL,
        SPECIAL,
        STATUS
    }
}
