﻿using BitmonGeneration1.Source.Moves;
using BitmonGeneration1.Source.BitmonData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitmonGeneration1.Source.Battles
{
    public class BattleBitmonEventArgs : EventArgs
    {
        public Bitmon bitmon;
        public BattleBitmon battleBitmon;
    }

    public class GainedExpEventArgs : BattleBitmonEventArgs
    {
        public float gainedExp;
    }


    public class GainedHPEventArgs : BattleBitmonEventArgs
    {
        public float gainedHP;
    }

    public class MoveEventArgs : BattleBitmonEventArgs
    {
        public Move move;
    }

    public class StatStageChangedEventArgs : BattleBitmonEventArgs
    {
        public StatType statChanged;
        public int change;
    }

    public class SwitchedOutEventArgs : BattleBitmonEventArgs
    {
        public Bitmon switchIn;
    }

    public class MimicMoveEventArgs : BattleBitmonEventArgs
    {
        public BattleBitmon opponent;
        public Move moveMimiced;
    }

    public class TransformedEventArgs : BattleBitmonEventArgs
    {
        public BattleBitmon transformInto;
    }

}
